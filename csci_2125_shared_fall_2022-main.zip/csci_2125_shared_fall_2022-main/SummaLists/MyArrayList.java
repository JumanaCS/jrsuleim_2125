public class MyArrayList<AnyType> {

    // instance variables
    private Object[] theData; // this MUST be declared as Object because I
                  // cannot declare it as AnyType (not allowed)
    private int size;  // actually how many elements there are

    // constructor
    public MyArrayList() {
        theData = new Object[10];
        size = 0;
    }
    
    public int size() {
        return this.size;
    }

    public void add(AnyType element) {
        if (size >= theData.length)
            expandStorage();
        theData[size] = element;
        size++;
    }

    public AnyType get(int index) {
        if (index >= size)
            throw new IndexOutOfBoundsException("index is too big!");
        else if (index < 0) 
            throw new IndexOutOfBoundsException("Have you lost your mind?");
        return (AnyType)(theData[index]);

    }

    public AnyType remove(int index) {
        if (index >= size)
            throw new IndexOutOfBoundsException("index is too big!");
        else if (index < 0) 
            throw new IndexOutOfBoundsException("Have you lost your mind?");

        if (size >= theData.length)
            expandStorage();

        AnyType thingToReturn = (AnyType)(theData[index]);
        for (int i=index; i<size-1; i++) {
            theData[i] = theData[i+1];
        }
        theData[size-1] = null;
        size--;
        return thingToReturn;
    }

    public void add(AnyType element, int index) {
        if (index > size)
            throw new IndexOutOfBoundsException("index is too big!");
        else if (index < 0) 
            throw new IndexOutOfBoundsException("Have you lost your mind?");
        if (index == size){
            add(element);
            return;
            }

        if (size >= theData.length)
            expandStorage();

        for (int i = size-1; i>= index; i--) {
            theData[i+1] = theData[i];
        }

        theData[index] = element;
        size++;

    }

    public void set(AnyType element, int index) {
        if (index >= size)
            throw new IndexOutOfBoundsException("index is too big!");
        else if (index < 0) 
            throw new IndexOutOfBoundsException("Have you lost your mind?");

        theData[index] = element;    
    }

    private void expandStorage() {
        // we want to build the new data store to be ~1.5X the original size
        int newSize = theData.length + theData.length / 2 + 1;

        Object[] biggerArray = new Object[newSize];
        for (int i=0; i<size; i++) {
            biggerArray[i] = theData[i];
        }
        this.theData = biggerArray;

    }

    public MyIterator iterator() {
        return new MyIterator();
    }


    public void makeEmpty() {
        // let the automated garbage collection machinery
        // do the deed;
        theData = new Object[10];
        size = 0;

        // or...
        /*
        for (int i=0 ;i<size; i++)
            theData[i] = null;
        size =0;
        */
    }

    public class MyIterator {

        // instance variables
        private int currentIndex;
        
        public MyIterator() {
            this.currentIndex = 0;
        }

        public boolean hasNext() {
            if (currentIndex >= size)
                return false;
            return true;
        }

        public AnyType next() {
            AnyType returnValue = (AnyType)(theData[currentIndex]);
            this.currentIndex++;
            return returnValue;
            // also can be done in one line
            // return (AnyType)(theData[currentIndex++]);
        }
            

    }



}
