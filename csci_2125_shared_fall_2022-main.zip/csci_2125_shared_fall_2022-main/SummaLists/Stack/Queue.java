public class Queue<AnyType> {

    private MyArrayList<AnyType> data;

    public Queue() {
        data = new MyArrayList();
    }


    public void enqueue(AnyType element) {

        // let's assume entry point is at index 0 and exit point is at size-1
        //data.add(0,element);
        // O(N)
        
        
        // let's assume entry point is at index size-1 and exit point is at 0
        data.add(element)
        // O(1) sometimes O(N)
    }

    public AnyType dequeue() {
        // let's assume entry point is at index 0 and exit point is at size-1
        //return data.remove(data.size()-1);
        // O(1)
        
        // let's assume entry point is at index size-1 and exit point is at 0
        return data.remove(0);
        // O(N)

    }

    public AnyType peek() {
        // let's assume entry point is at index 0 and exit point is at size-1
        //return data.get(data.size()-1);
        // O(1)
       
        // let's assume entry point is at index size-1 and exit point is at 0
        return data.get(0);
        // O(1);

    }



} // end class Queue
