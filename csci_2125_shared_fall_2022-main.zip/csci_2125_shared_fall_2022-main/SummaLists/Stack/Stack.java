public class Stack<AnyType> {

    private MyArrayList<AnyType> data;

    public Stack() {
        data = new MyArrayList();
    }


    public void push(AnyType element) {

        // let's imagine the "top" is at index 0
        // data.add(element,0);
        // O(N) -- poor choice!

        // let's imagine the "top" is at the end (size-1)
        data.add(element);
        // usually O(1) but sometimes O(N)

    }

    public AnyType pop() {
        // let's imagine the "top" is at index 0
        // return data.remove(0);
        // O(N) -- poor choice!

        // let's imagine the "top" is at the end (size-1)
        return data.remove(data.size()-1);
        // O(1) !!!
    }

    public AnyType peek() {

        // let's imagine the "top" is at index 0
        // return data.get(0);
        // O(1)


        // let's imagine the "top" is at the end (size-1)
        return data.get(data.size()-1);
        // O(1)
    }


}
