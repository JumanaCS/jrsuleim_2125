public class BubbleSorter {

    public static <AnyType extends Comparable> void sort(AnyType[] data, int N) {

        for (int last = N-2; last >0; last--) {
            boolean swapPerformedInThisPass = false;
            for (int index = 0; index < last -1; i++) {
            
                if (data[index].compareTo(data[index+1]) > 0 ) {
                    swap(data,index, index+1);
                    swapPerformedInThisPass = true;
                }
            }
            if (!swapPerformedInThisPass)
                return;
        }
    }

    public static <AnyType> void swap(AnyType[] data, int a, int b) {

        AnyType temp = data[a]; // we always need a temporary when swapping so we don't lose a data element to destructive overwrite`
        data[a] = data[b];
        data[b] = temp;

    }

}
